# Anonymous WACV 2027 supplementary artifact

This package contains source, locked configurations, aggregate result tables, manifests, tests, and paper figures. It deliberately excludes all third-party model weights, direction tensors, face embeddings, and full generated-image campaigns.

Install the exact dependencies from `requirements-lock.txt`, then run `python -m pip install -e . --no-deps` and `make check`. See `docs/REPRODUCIBILITY.md` for the analysis and claim-audit commands.
