# Anonymous WACV 2027 supplementary artifact

This package contains source, locked configurations, aggregate result tables, manifests, tests, and paper figures. It deliberately excludes all third-party model weights, direction tensors, face embeddings, and full generated-image campaigns. See docs/REPRODUCIBILITY.md for commands.
